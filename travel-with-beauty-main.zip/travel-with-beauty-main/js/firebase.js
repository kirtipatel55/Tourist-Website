const firebaseConfig = {
    apiKey: "AIzaSyBCDv3fhU1q9KBr7NCt6mog5MQcG0ccA1k",
    authDomain: "travel-and-tourism-d809d.firebaseapp.com",
    projectId: "travel-and-tourism-d809d",
    storageBucket: "travel-and-tourism-d809d.appspot.com",
    messagingSenderId: "1075296524474",
    appId: "1:1075296524474:web:3116f2b943372824618a83",
    measurementId: "G-7XW50BX8EQ"
  };

  firebase.initializeApp(firebaseConfig);